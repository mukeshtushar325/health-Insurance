# Insurance Forecast by using Linear Regression

### Heroku Deployment
http://healthinsuranceprediction.herokuapp.com/


### Output
<img src="Screenshoot/output.png" width="600">


